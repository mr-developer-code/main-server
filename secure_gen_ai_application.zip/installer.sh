#!/bin/bash
# Go to directory where script is
cd "$(dirname "$0")"

# Run the Python installer
sudo python3 main.py
read -p "Press Enter to Exit..."

#--------------------------------------------------------------------------------
