from utils_main import * 
import os
import multiprocessing
import time

commands_config = [
    "sudo python3 scripts/post_progress_bar.py"
]
process = []

def main_node(): 
    print("Started")

    os.makedirs("/sgi/modules", exist_ok=True)
    os.makedirs("/sgi/scripts", exist_ok=True)
    os.makedirs("/sgi/sur_files", exist_ok=True)

    os.chdir("/sgi")

    interface_name = (run_command_simple("ip route get 1 | awk '{print $5; exit}'")).strip()
    inet_add_data = (run_command_simple(f"ip -4 addr show dev {interface_name.strip()} | grep -oP '(?<=inet\\s)\\d+(\\.\\d+){{3}}+'")).strip().split("\n")[0]

    run_command("sudo git clone https://github.com/mr-developer-code/nDPI.git modules")
    run_command("sudo git clone https://github.com/mr-developer-code/nprobe.git modules/nprobe")
    run_command("sudo git clone https://github.com/mr-developer-code/PF_RING.git modules/PF_RING")
    run_command("sudo git clone https://github.com/mr-developer-code/suricata-8.0.0.git modules/suricata-8.0.0")
    run_command("sudo git clone https://github.com/mr-developer-code/scripts.git scripts")
    run_command("sudo git clone https://github.com/mr-developer-code/sur_files.git sur_files")
    
    run_command("sudo pip3 install -r sur_files/req.txt")

    ## save ip address to store data on server
    with open ("/sgi/sur_files/address.txt", "w") as f:
        f.write(inet_add_data)

    with open("/sgi/sur_files/progress.txt","w") as f:
        f.write(str(0))
    
    # os.chdir("/sgi/scripts")

    for cmd in commands_config:
        p = multiprocessing.Process(target=run_command, args=(cmd,))
        p.start()
        process.append(p)
    
    run_command("sudo python3 scripts/suricata_configuration.py")

    with open("/sgi/sur_files/progress.txt","w") as f:
        f.write(str(100))

    time.sleep(10)
    for p in process:
        p.terminate()

main_node()

#--------------------------------------------------------------------------------